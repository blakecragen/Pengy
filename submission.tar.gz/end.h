/*
 * Exported with nin10kit v1.3
 * Time-stamp: Wednesday 04/06/2016, 01:55:42
 * 
 * Image Information
 * -----------------
 * /home/nishant/Desktop/HW09/end.jpg 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef END_H
#define END_H

extern const unsigned short End[38400];
#define END_SIZE 38400
#define END_WIDTH 240
#define END_HEIGHT 160

#endif

