Game: Pengy Paradise

Our friend Pengy the Penguin in chillin in his house. He decides that we wants to go on a walk outside. When he gets outside, his friends try to prank him by throwing snowballs at him.
Pengy is a very delicate penguin who likes to keep his... feathers(?)... nice and clean. Thus, he tries his best to avoid the snowballs. 
As time goes on, his friends persist in trying to hit him and throw more snowballs faster. See how long you can keep Pengy's feathers clean!

Up Button: Jump to top platform
Down Button: Jump to bottom platform
Left Button: Move to the left
Right Button: Move the the right
Start Button: Progress through screens (start/directions)
Select Button: Reset game