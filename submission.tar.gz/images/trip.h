/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x50 trip trip.png 
 * Time-stamp: Monday 07/17/2023, 20:54:14
 * 
 * Image Information
 * -----------------
 * trip.png 40@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TRIP_H
#define TRIP_H

extern const unsigned short trip[2000];
#define TRIP_SIZE 4000
#define TRIP_LENGTH 2000
#define TRIP_WIDTH 40
#define TRIP_HEIGHT 50

#endif

