/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x50 leftDown leftDown.png 
 * Time-stamp: Monday 07/17/2023, 20:52:59
 * 
 * Image Information
 * -----------------
 * leftDown.png 40@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LEFTDOWN_H
#define LEFTDOWN_H

extern const unsigned short leftDown[2000];
#define LEFTDOWN_SIZE 4000
#define LEFTDOWN_LENGTH 2000
#define LEFTDOWN_WIDTH 40
#define LEFTDOWN_HEIGHT 50

#endif

