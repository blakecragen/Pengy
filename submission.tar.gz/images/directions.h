/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 directions directions.png 
 * Time-stamp: Sunday 07/16/2023, 23:44:22
 * 
 * Image Information
 * -----------------
 * directions.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DIRECTIONS_H
#define DIRECTIONS_H

extern const unsigned short directions[38400];
#define DIRECTIONS_SIZE 76800
#define DIRECTIONS_LENGTH 38400
#define DIRECTIONS_WIDTH 240
#define DIRECTIONS_HEIGHT 160

#endif

