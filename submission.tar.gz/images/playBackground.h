/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=160x240 playBackground playBackground.png 
 * Time-stamp: Monday 07/17/2023, 20:35:39
 * 
 * Image Information
 * -----------------
 * playBackground.png 160@240
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYBACKGROUND_H
#define PLAYBACKGROUND_H

extern const unsigned short playBackground[38400];
#define PLAYBACKGROUND_SIZE 76800
#define PLAYBACKGROUND_LENGTH 38400
#define PLAYBACKGROUND_WIDTH 160
#define PLAYBACKGROUND_HEIGHT 240

#endif

