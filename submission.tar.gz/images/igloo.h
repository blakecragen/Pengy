/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=80x80 igloo startScreen.png 
 * Time-stamp: Sunday 07/16/2023, 23:05:19
 * 
 * Image Information
 * -----------------
 * startScreen.png 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IGLOO_H
#define IGLOO_H

extern const unsigned short startScreen[6400];
#define STARTSCREEN_SIZE 12800
#define STARTSCREEN_LENGTH 6400
#define STARTSCREEN_WIDTH 80
#define STARTSCREEN_HEIGHT 80

#endif

