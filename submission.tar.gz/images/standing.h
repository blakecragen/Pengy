/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x50 standing standing.png 
 * Time-stamp: Monday 07/17/2023, 20:54:02
 * 
 * Image Information
 * -----------------
 * standing.png 40@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STANDING_H
#define STANDING_H

extern const unsigned short standing[2000];
#define STANDING_SIZE 4000
#define STANDING_LENGTH 2000
#define STANDING_WIDTH 40
#define STANDING_HEIGHT 50

#endif

