/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x30 snowball snowball.png 
 * Time-stamp: Monday 07/17/2023, 20:53:48
 * 
 * Image Information
 * -----------------
 * snowball.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOWBALL_H
#define SNOWBALL_H

extern const unsigned short snowball[900];
#define SNOWBALL_SIZE 1800
#define SNOWBALL_LENGTH 900
#define SNOWBALL_WIDTH 30
#define SNOWBALL_HEIGHT 30

#endif

