/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x50 leftStep leftStep.png 
 * Time-stamp: Monday 07/17/2023, 20:53:11
 * 
 * Image Information
 * -----------------
 * leftStep.png 40@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LEFTSTEP_H
#define LEFTSTEP_H

extern const unsigned short leftStep[2000];
#define LEFTSTEP_SIZE 4000
#define LEFTSTEP_LENGTH 2000
#define LEFTSTEP_WIDTH 40
#define LEFTSTEP_HEIGHT 50

#endif

