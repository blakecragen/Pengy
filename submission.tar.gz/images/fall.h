/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x30 fall fall.png 
 * Time-stamp: Monday 07/17/2023, 20:52:32
 * 
 * Image Information
 * -----------------
 * fall.png 40@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FALL_H
#define FALL_H

extern const unsigned short fall[1200];
#define FALL_SIZE 2400
#define FALL_LENGTH 1200
#define FALL_WIDTH 40
#define FALL_HEIGHT 30

#endif

